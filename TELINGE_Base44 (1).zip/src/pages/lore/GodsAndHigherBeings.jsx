import React from "react";
import LorePageHeader from "../../components/lore/LorePageHeader";
import SubsectionCard from "../../components/lore/SubsectionCard";
import { Crown } from "lucide-react";

const subsections = [
  {
    title: "The Voices",
    description: "Enigmatic entities that speak from beyond the veil — their words shape the course of fate itself.",
  },
  {
    title: "Gods",
    description: "The divine architects of reality, each commanding dominion over the fundamental forces of Telinge.",
  },
  {
    title: "Dragons",
    description: "Ancient and primordial beings of immeasurable power, older than the gods themselves.",
  },
  {
    title: "Concepts",
    description: "The living embodiments of abstract ideas — Truth, Chaos, Time, and others made manifest.",
  },
  {
    title: "Absolutes",
    description: "The immutable constants of existence — forces so fundamental that even the gods cannot defy them.",
  },
];

export default function GodsAndHigherBeings() {
  return (
    <div>
      <LorePageHeader
        title="Gods & Higher Beings"
        sectorCode="SECTOR_03 // DIVINITY"
        description="The supreme entities that tower above mortal comprehension — from the whispered Voices to the immovable Absolutes."
        icon={Crown}
      />
      <div className="max-w-4xl mx-auto px-6 pb-32">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {subsections.map((sub, i) => (
            <SubsectionCard key={sub.title} {...sub} index={i} />
          ))}
        </div>
      </div>
    </div>
  );
}