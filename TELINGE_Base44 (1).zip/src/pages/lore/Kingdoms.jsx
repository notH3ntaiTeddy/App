import React from "react";
import LorePageHeader from "../../components/lore/LorePageHeader";
import SubsectionCard from "../../components/lore/SubsectionCard";
import { Castle } from "lucide-react";

const subsections = [
  {
    title: "The Island of Geddos",
    description: "A landmass shrouded in legend and conflict — the cradle of civilizations and the stage upon which empires rise and fall.",
    restricted: false,
  },
  {
    title: "The Unknown",
    description: "Beyond the charted edges of the map — territories whispered about in taverns, where no expedition has returned unchanged.",
    restricted: false,
  },
];

const emptySubsections = [
  {
    title: "Region Yet Unnamed",
    description: "This territory has not yet been surveyed by the cartographers of the Codex.",
    restricted: true,
  },
  {
    title: "Territory Pending",
    description: "The boundaries of this realm remain in flux — its identity has not yet been committed to record.",
    restricted: true,
  },
  {
    title: "Uncharted Domain",
    description: "Expeditions to this region have returned with conflicting accounts. Further investigation required.",
    restricted: true,
  },
  {
    title: "Lost Province",
    description: "References to this land exist only in fragments of pre-creation texts. Its existence remains unconfirmed.",
    restricted: true,
  },
];

export default function Kingdoms() {
  return (
    <div>
      <LorePageHeader
        title="Kingdoms"
        sectorCode="SECTOR_06 // GEOGRAPHY"
        description="The lands and sovereign territories of Telinge — from the known kingdoms to realms that exist only at the edge of understanding."
        icon={Castle}
      />
      <div className="max-w-4xl mx-auto px-6 pb-32">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {subsections.map((sub, i) => (
            <SubsectionCard key={sub.title} {...sub} index={i} />
          ))}
        </div>

        <div className="mb-6">
          <p className="font-inter text-[10px] tracking-[0.3em] uppercase text-muted-foreground/30 mb-4">
            ▣ UNCHARTED TERRITORIES
          </p>
          <div className="w-full h-px bg-border/20 mb-6" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {emptySubsections.map((sub, i) => (
            <SubsectionCard key={sub.title} {...sub} index={i} />
          ))}
        </div>
      </div>
    </div>
  );
}