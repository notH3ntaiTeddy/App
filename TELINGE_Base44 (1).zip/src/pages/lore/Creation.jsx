import React from "react";
import LorePageHeader from "../../components/lore/LorePageHeader";
import PlaceholderContent from "../../components/lore/PlaceholderContent";
import { Sparkles } from "lucide-react";

export default function Creation() {
  return (
    <div>
      <LorePageHeader
        title="Creation"
        sectorCode="SECTOR_01 // CREATION"
        description="The genesis of all existence — how from void the first light was born. The birth of the Gods and the Higher Beings and the gift of the multiverse."
        icon={Sparkles}
      />
      <PlaceholderContent />
    </div>
  );
}