import React from "react";
import LorePageHeader from "../../components/lore/LorePageHeader";
import SubsectionCard from "../../components/lore/SubsectionCard";
import { Skull } from "lucide-react";

const subsections = [
  {
    title: "Monsters",
    description: "Nightmares made flesh — creatures of unnatural origin that stalk the dark corners of the world, driven by hunger, malice, or ancient purpose.",
  },
  {
    title: "Animals",
    description: "The natural fauna of Telinge — from the mundane beasts of burden to the exotic creatures that inhabit its most remote regions.",
  },
];

export default function MonstersAndAnimals() {
  return (
    <div>
      <LorePageHeader
        title="Monsters & Animals"
        sectorCode="SECTOR_05 // BESTIARY"
        description="A catalogue of every creature that roams, crawls, flies, or lurks within the world of Telinge."
        icon={Skull}
      />
      <div className="max-w-4xl mx-auto px-6 pb-32">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {subsections.map((sub, i) => (
            <SubsectionCard key={sub.title} {...sub} index={i} />
          ))}
        </div>
      </div>
    </div>
  );
}