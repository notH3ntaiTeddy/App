import React from "react";
import LorePageHeader from "../../components/lore/LorePageHeader";
import PlaceholderContent from "../../components/lore/PlaceholderContent";
import { Eye } from "lucide-react";

export default function Prophecies() {
  return (
    <div>
      <LorePageHeader
        title="Prophecies"
        sectorCode="SECTOR_08 // FATE"
        description="Foretellings carved in stone, whispered by oracles, and bled onto ancient scrolls — the prophecies that drive the destiny of all creation."
        icon={Eye}
      />
      <PlaceholderContent />
    </div>
  );
}