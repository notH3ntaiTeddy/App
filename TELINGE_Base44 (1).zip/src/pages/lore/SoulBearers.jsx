import React from "react";
import LorePageHeader from "../../components/lore/LorePageHeader";
import SubsectionCard from "../../components/lore/SubsectionCard";
import { Users } from "lucide-react";

const subsections = [
  {
    title: "Humanoids",
    description: "The most numerous of the sentient races — humans and those who share their form, bound by mortal frames and endless ambition.",
  },
  {
    title: "Demi-Humanoids",
    description: "Beings caught between the mortal and the mythical — part human in form, yet touched by something far older and stranger.",
  },
  {
    title: "Heteromorphics",
    description: "Intelligent creatures whose forms defy human classification — alien minds housed in shapes both wondrous and terrifying.",
  },
];

export default function SoulBearers() {
  return (
    <div>
      <LorePageHeader
        title="Soul-Bearers"
        sectorCode="SECTOR_04 // SPECIES"
        description="The sentient races of Telinge — all who carry the spark of the soul, from the most familiar to the utterly alien."
        icon={Users}
      />
      <div className="max-w-4xl mx-auto px-6 pb-32">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {subsections.map((sub, i) => (
            <SubsectionCard key={sub.title} {...sub} index={i} />
          ))}
        </div>
      </div>
    </div>
  );
}