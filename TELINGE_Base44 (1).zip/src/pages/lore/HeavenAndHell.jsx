import React from "react";
import LorePageHeader from "../../components/lore/LorePageHeader";
import PlaceholderContent from "../../components/lore/PlaceholderContent";
import { Scroll } from "lucide-react";

export default function HeavenAndHell() {
  return (
    <div>
      <LorePageHeader
        title="Heaven & Hell"
        sectorCode="SECTOR_09 // AFTERLIFE"
        description="The planes that await beyond the threshold of death — realms of eternal grace and domains of unending torment, where the soul's final judgment is rendered."
        icon={Scroll}
      />
      <PlaceholderContent />
    </div>
  );
}