import React from "react";
import LorePageHeader from "../../components/lore/LorePageHeader";
import PlaceholderContent from "../../components/lore/PlaceholderContent";
import { Flame } from "lucide-react";

export default function NaturalAbilities() {
  return (
    <div>
      <LorePageHeader
        title="Natural Abilities"
        sectorCode="SECTOR_07 // POWER"
        description="The inherent gifts woven into the essence of Telinge's inhabitants — from elemental affinities to innate arcane talents that defy mortal understanding."
        icon={Flame}
      />
      <PlaceholderContent />
    </div>
  );
}