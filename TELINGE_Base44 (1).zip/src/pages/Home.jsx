import React from "react";
import HeroSection from "../components/home/HeroSection";
import AuthorsSection from "../components/home/AuthorsSection";
import CodexSection from "../components/home/CodexSection";

export default function Home() {
  return (
    <div>
      <HeroSection />
      <AuthorsSection />
      <CodexSection />
    </div>
  );
}