import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';

import AppLayout from './components/layout/AppLayout';
import Home from './pages/Home';
import Creation from './pages/lore/Creation';
import ReligionAndTraditions from './pages/lore/ReligionAndTraditions';
import GodsAndHigherBeings from './pages/lore/GodsAndHigherBeings';
import SoulBearers from './pages/lore/SoulBearers';
import MonstersAndAnimals from './pages/lore/MonstersAndAnimals';
import Kingdoms from './pages/lore/Kingdoms';
import NaturalAbilities from './pages/lore/NaturalAbilities';
import Prophecies from './pages/lore/Prophecies';
import HeavenAndHell from './pages/lore/HeavenAndHell';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/lore/creation" element={<Creation />} />
        <Route path="/lore/religion-and-traditions" element={<ReligionAndTraditions />} />
        <Route path="/lore/gods-and-higher-beings" element={<GodsAndHigherBeings />} />
        <Route path="/lore/soul-bearers" element={<SoulBearers />} />
        <Route path="/lore/monsters-and-animals" element={<MonstersAndAnimals />} />
        <Route path="/lore/kingdoms" element={<Kingdoms />} />
        <Route path="/lore/natural-abilities" element={<NaturalAbilities />} />
        <Route path="/lore/prophecies" element={<Prophecies />} />
        <Route path="/lore/heaven-and-hell" element={<HeavenAndHell />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App