import React from "react";
import { Outlet } from "react-router-dom";
import FloatingNav from "./FloatingNav";

export default function AppLayout() {
  return (
    <div className="min-h-screen bg-background relative">
      {/* Meridian line */}
      <div className="meridian-line" />
      
      {/* Main content */}
      <main className="relative z-10">
        <Outlet />
      </main>

      {/* Floating navigation */}
      <FloatingNav />
    </div>
  );
}