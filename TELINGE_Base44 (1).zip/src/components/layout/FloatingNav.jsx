import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Compass, X, Home, Scroll, Crown, Users, Skull, Castle, Sparkles, BookOpen, Flame, Eye } from "lucide-react";

const navSections = [
  { label: "Home", path: "/", icon: Home },
  { label: "Creation", path: "/lore/creation", icon: Sparkles },
  { label: "Religion & Traditions", path: "/lore/religion-and-traditions", icon: BookOpen },
  { label: "Gods & Higher Beings", path: "/lore/gods-and-higher-beings", icon: Crown },
  { label: "Soul-Bearers", path: "/lore/soul-bearers", icon: Users },
  { label: "Monsters & Animals", path: "/lore/monsters-and-animals", icon: Skull },
  { label: "Kingdoms", path: "/lore/kingdoms", icon: Castle },
  { label: "Natural Abilities", path: "/lore/natural-abilities", icon: Flame },
  { label: "Prophecies", path: "/lore/prophecies", icon: Eye },
  { label: "Heaven & Hell", path: "/lore/heaven-and-hell", icon: Scroll },
];

export default function FloatingNav() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  return (
    <>
      {/* Floating compass button */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-card border border-border flex items-center justify-center shadow-lg shadow-primary/10 hover:shadow-primary/30 transition-shadow"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <X className="w-5 h-5 text-primary" />
            </motion.div>
          ) : (
            <motion.div key="open" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}>
              <Compass className="w-5 h-5 text-primary" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Full-screen nav overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 bg-background/95 backdrop-blur-xl flex items-center justify-center"
            onClick={() => setIsOpen(false)}
          >
            <motion.nav
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 30 }}
              transition={{ duration: 0.4, delay: 0.1 }}
              className="grid grid-cols-1 sm:grid-cols-2 gap-3 px-6 max-w-2xl w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <p className="col-span-full text-center font-cinzel text-primary text-xs tracking-widest uppercase mb-4">
                Navigate the Codex
              </p>
              {navSections.map((item, i) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <motion.div
                    key={item.path}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.05 * i }}
                  >
                    <Link
                      to={item.path}
                      onClick={() => setIsOpen(false)}
                      className={`flex items-center gap-3 px-5 py-4 rounded-lg border transition-all duration-300 group
                        ${isActive
                          ? "bg-primary/10 border-primary/40 text-primary"
                          : "bg-card/50 border-border/50 text-foreground hover:border-primary/30 hover:bg-primary/5"
                        }`}
                    >
                      <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? "text-primary" : "text-muted-foreground group-hover:text-primary"} transition-colors`} />
                      <span className="font-cinzel-body text-sm tracking-wide">{item.label}</span>
                    </Link>
                  </motion.div>
                );
              })}
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}