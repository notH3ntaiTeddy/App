import React from "react";
import { motion } from "framer-motion";
import LoreSectionCard from "./LoreSectionCard";
import { Sparkles, BookOpen, Crown, Users, Skull, Castle, Flame, Eye, Scroll } from "lucide-react";

const loreSections = [
  {
    label: "Creation",
    path: "/lore/creation",
    sectorCode: "SECTOR_01 // CREATION",
    icon: Sparkles,
    description: "The genesis of all existence — how from void, the world was born.",
  },
  {
    label: "Religion & Traditions",
    path: "/lore/religion-and-traditions",
    sectorCode: "SECTOR_02 // FAITH",
    icon: BookOpen,
    description: "The belief systems, rites, and customs that bind civilization.",
  },
  {
    label: "Gods & Higher Beings",
    path: "/lore/gods-and-higher-beings",
    sectorCode: "SECTOR_03 // DIVINITY",
    icon: Crown,
    description: "The Voices, Gods, Dragons, Concepts, and Absolutes that shape reality.",
  },
  {
    label: "Soul-Bearers",
    path: "/lore/soul-bearers",
    sectorCode: "SECTOR_04 // SPECIES",
    icon: Users,
    description: "Humanoids, Demi-Humanoids, and Heteromorphics — the sentient races.",
  },
  {
    label: "Monsters & Animals",
    path: "/lore/monsters-and-animals",
    sectorCode: "SECTOR_05 // BESTIARY",
    icon: Skull,
    description: "Creatures of terror and wonder that roam the untamed lands.",
  },
  {
    label: "Kingdoms",
    path: "/lore/kingdoms",
    sectorCode: "SECTOR_06 // GEOGRAPHY",
    icon: Castle,
    description: "The Island of Geddos, the Unknown, and realms yet to be charted.",
  },
  {
    label: "Natural Abilities",
    path: "/lore/natural-abilities",
    sectorCode: "SECTOR_07 // POWER",
    icon: Flame,
    description: "The inherent gifts and arcane talents woven into the fabric of life.",
  },
  {
    label: "Prophecies",
    path: "/lore/prophecies",
    sectorCode: "SECTOR_08 // FATE",
    icon: Eye,
    description: "The foretold events that drive the destiny of all creation.",
  },
  {
    label: "Heaven & Hell",
    path: "/lore/heaven-and-hell",
    sectorCode: "SECTOR_09 // AFTERLIFE",
    icon: Scroll,
    description: "The planes beyond death — the horrors before the unending reward.",
  },
];

export default function CodexSection() {
  return (
    <section className="py-32 px-6 relative">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="max-w-5xl mx-auto"
      >
        <p className="font-inter text-xs tracking-[0.3em] uppercase text-muted-foreground text-center mb-4">
          THE CODEX
        </p>
        <h2 className="font-cinzel text-3xl sm:text-4xl text-center text-foreground mb-16">
          Explore the World
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {loreSections.map((section, i) => (
            <LoreSectionCard key={section.path} {...section} delay={i * 0.05} />
          ))}
        </div>
      </motion.div>
    </section>
  );
}