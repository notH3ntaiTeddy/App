import React from "react";
import { motion } from "framer-motion";
import AuthorCard from "./AuthorCard";

const AUTHOR1_IMG = "https://cdn.discordapp.com/attachments/1473281378907852970/1490415582544396459/channels4_profile_1.png?ex=69d3f92d&is=69d2a7ad&hm=985f4db91d3f30f738e2f275e1af07322cbdcbd511816d3228db94750ab1e017";
const AUTHOR2_IMG = "https://cdn.discordapp.com/attachments/1473281378907852970/1490416096149373101/Profil.jpeg?ex=69d3f9a7&is=69d2a827&hm=196c01741f9b481d1ee4df9256498b8fd30682f9fc5a722718ba6e003d9156c7";

export default function AuthorsSection() {
  return (
    <section className="py-32 px-6 relative">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="max-w-4xl mx-auto">
        
        <p className="text-muted-foreground mb-4 text-xs font-inter text-center uppercase tracking-[0.3em] opacity-0">SECTOR_00.1 // AUTHORS

        </p>
        <h2 className="font-cinzel text-3xl sm:text-4xl text-center text-foreground mb-4">
          The Architects
        </h2>
        <p className="text-muted-foreground text-center max-w-md mx-auto mb-16 font-inter text-sm leading-relaxed">The minds behind the world of Telinge — weaving their thoughts into an entire world.

        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-16 sm:gap-8">
          <AuthorCard
            name="notH3ntaiTeddy"
            avatar={AUTHOR1_IMG}
            socialUrl="https://linktr.ee/noth3ntaiteddy"
            socialLabel="Linktree"
            delay={0.1} />
          
          <AuthorCard
            name="CatsDragon"
            avatar={AUTHOR2_IMG}
            socialUrl=""
            delay={0.3}
            placeholder />
          
        </div>
      </motion.div>
    </section>);

}