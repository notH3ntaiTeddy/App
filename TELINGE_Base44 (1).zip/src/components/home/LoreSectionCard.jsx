import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ChevronRight } from "lucide-react";

export default function LoreSectionCard({ label, path, sectorCode, icon: Icon, description, delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.6, delay }}>
      
      <Link
        to={path}
        className="block p-6 rounded-lg border border-border/40 bg-card/30 hover:bg-card/60 hover:border-primary/30 hover:shadow-xl hover:shadow-primary/5 transition-all duration-500 group noise-texture relative overflow-hidden">
        
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              {Icon && <Icon className="w-5 h-5 text-primary/60 group-hover:text-primary transition-colors" />}
              <p className="text-muted-foreground/60 font-inter uppercase tracking-[0.25em] opacity-0">
                {sectorCode}
              </p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground/30 group-hover:text-primary/60 group-hover:translate-x-1 transition-all" />
          </div>
          <h3 className="font-cinzel-body text-lg text-foreground group-hover:text-primary/90 transition-colors tracking-wide mb-2">
            {label}
          </h3>
          <p className="font-inter text-sm text-muted-foreground/70 leading-relaxed">
            {description}
          </p>
        </div>
      </Link>
    </motion.div>);

}