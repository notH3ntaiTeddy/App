import React from "react";
import { motion } from "framer-motion";
import { ExternalLink } from "lucide-react";

export default function AuthorCard({ name, avatar, socialUrl, socialLabel, delay = 0, placeholder = false }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, delay }}
      className="flex flex-col items-center text-center group"
    >
      {/* Avatar */}
      <div className="relative w-32 h-32 sm:w-40 sm:h-40 rounded-full overflow-hidden mb-6 border border-border/50 group-hover:border-primary/40 transition-colors duration-500">
        <img
          src={avatar}
          alt={name}
          className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
        />
        <div className="absolute inset-0 bg-primary/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      </div>

      {/* Name */}
      <h3 className="font-cinzel-body text-lg sm:text-xl text-foreground tracking-wide mb-3">
        {name}
      </h3>

      {/* Social link */}
      {socialUrl ? (
        <a
          href={socialUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg border border-border/50 text-sm text-muted-foreground hover:text-primary hover:border-primary/40 hover:bg-primary/5 hover:shadow-lg hover:shadow-primary/10 transition-all duration-300 font-inter"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          {socialLabel || "Links"}
        </a>
      ) : (
        <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg border border-border/30 text-sm text-muted-foreground/50 font-inter italic">
          Awaiting Signature
        </div>
      )}
    </motion.div>
  );
}