const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from "react";
import { motion } from "framer-motion";

const HERO_BG = "https://media.db.com/images/public/69d29f0dfe85e4fc35c08e94/32edc4b1e_generated_7519ff8c.png";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src={HERO_BG}
          alt="Dark fantasy landscape"
          className="w-full h-full object-cover opacity-30" />
        
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/60 to-background" />
      </div>

      {/* Content */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.2, ease: "easeOut" }}
        className="relative z-10 text-center px-6">
        
        <p className="text-muted-foreground mb-8 text-xs font-inter uppercase tracking-[0.3em] opacity-0">SECTOR_00 // THRESHOLD

        </p>

        <h1 className="text-shimmer font-cinzel text-6xl sm:text-8xl md:text-9xl font-bold tracking-tight leading-none cursor-default select-none">
          TELINGE
        </h1>

        <div className="w-16 h-px bg-primary/40 mx-auto my-8" />

        <p className="font-inter text-lg sm:text-xl text-foreground/80 max-w-lg mx-auto leading-relaxed">
          The entire LORE behind the world of TELINGE
        </p>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2">
        
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-px h-10 bg-gradient-to-b from-primary/50 to-transparent" />
        
      </motion.div>
    </section>);

}