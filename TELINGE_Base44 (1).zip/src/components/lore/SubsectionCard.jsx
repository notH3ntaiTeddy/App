import React from "react";
import { motion } from "framer-motion";

export default function SubsectionCard({ title, description, index = 0, restricted = false }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.6, delay: index * 0.08 }}
      className={`p-6 rounded-lg border transition-all duration-300 noise-texture relative overflow-hidden ${
        restricted
          ? "border-border/20 bg-card/10"
          : "border-border/40 bg-card/30 hover:border-primary/30 hover:bg-card/50"
      }`}
    >
      <div className="relative z-10">
        {restricted && (
          <p className="font-inter text-[9px] tracking-[0.3em] uppercase text-primary/40 mb-3">
            ▣ UNCHARTED TERRITORY
          </p>
        )}
        <h3 className={`font-cinzel-body text-lg tracking-wide mb-3 ${
          restricted ? "text-muted-foreground/40" : "text-foreground"
        }`}>
          {title}
        </h3>
        <p className={`font-inter text-sm leading-relaxed ${
          restricted ? "text-muted-foreground/25 italic" : "text-muted-foreground/70"
        }`}>
          {description}
        </p>
        {restricted && (
          <p className="font-inter text-[10px] tracking-[0.2em] uppercase text-muted-foreground/20 mt-4">
            DATA RESTRICTED
          </p>
        )}
      </div>
    </motion.div>
  );
}