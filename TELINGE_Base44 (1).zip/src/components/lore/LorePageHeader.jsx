import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

export default function LorePageHeader({ title, sectorCode, description, icon: Icon }) {
  return (
    <header className="pt-12 pb-20 px-6 relative">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-10 font-inter"
          >
            <ArrowLeft className="w-4 h-4" />
            Return to Threshold
          </Link>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center gap-3 mb-6">
            {Icon && <Icon className="w-5 h-5 text-primary/60" />}
            <p className="font-inter text-xs tracking-[0.3em] uppercase text-muted-foreground">
              {sectorCode}
            </p>
          </div>

          <h1 className="font-cinzel text-4xl sm:text-5xl md:text-6xl text-foreground tracking-tight mb-6">
            {title}
          </h1>

          <div className="w-16 h-px bg-primary/40 mb-6" />

          <p className="font-inter text-lg text-muted-foreground max-w-2xl leading-relaxed">
            {description}
          </p>
        </motion.div>
      </div>
    </header>
  );
}