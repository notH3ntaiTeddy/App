import React from "react";
import { motion } from "framer-motion";

export default function PlaceholderContent() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      className="max-w-4xl mx-auto px-6 pb-32"
    >
      <div className="border border-border/20 rounded-lg p-8 bg-card/10 noise-texture relative overflow-hidden">
        <div className="relative z-10">
          <p className="font-inter text-sm text-muted-foreground/40 italic leading-relaxed">
            This chronicle entry awaits its inscription. The lore of this section has yet to be committed to the codex.
            Return when the scribes have finished their work.
          </p>
          <div className="mt-6 flex gap-2">
            <div className="w-2 h-2 rounded-full bg-primary/20" />
            <div className="w-2 h-2 rounded-full bg-primary/10" />
            <div className="w-2 h-2 rounded-full bg-primary/5" />
          </div>
        </div>
      </div>
    </motion.div>
  );
}